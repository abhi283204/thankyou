var $j = jQuery.noConflict();
$j(document).ready(function() {
//reset
$j( "input[name*='mycheckbox']" ).prop("checked", false);
$j( "input[name*='mycheckbox']").click(function(){

   if (!$j(this).is(":checked")) {

       //unchecked
    $j(this).parent().removeClass("active");  

    } else {
        //checked

    $j(this).parent().addClass("active"); 
    }

})

});