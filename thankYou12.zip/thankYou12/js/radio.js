var $j = jQuery.noConflict();
 $j(document).ready(function () {
    $j('#exampleRadios1').click(function () {
	 $j(this).parent().addClass('active1');
	 $j('#exampleRadios2').parent().removeClass('active1');
	  $j('#exampleRadios3').parent().removeClass('active1');
	  });
        
      $j('#exampleRadios2').click(function () {
	 $j(this).parent().addClass('active1');
	 $j('#exampleRadios1').parent().removeClass('active1');
	  $j('#exampleRadios3').parent().removeClass('active1');
	  });    

 $j('#exampleRadios3').click(function () {
	$j(this).parent().addClass('active1');
	 $j('#exampleRadios1').parent().removeClass('active1');
	  $j('#exampleRadios2').parent().removeClass('active1');
	  });
   
});