/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Set Header
3. Init Menu
4. Init Home Slider
5. Init Date Picker
6. Init SVG
7. Init Gallery
8. Init Testimonials Slider
9. Init Booking Slider
10. Init Blog Slider


******************************/
var $j = jQuery.noConflict();

$j(document).ready(function()
{
	"use strict";

	/* 

	1. Vars and Inits

	*/

	var header = $j('.header');

	setHeader();

	$j(window).on('resize', function()
	{
		setHeader();

		setTimeout(function()
		{
			$j(window).trigger('resize.px.parallax');
		}, 375);
	});

	$j(document).on('scroll', function()
	{
		setHeader();
	});

	initMenu();
	initHomeSlider();
	initDatePicker();
	initSvg();
	initGallery();
	initTestSlider();
	initBookingSlider();
	initBlogSlider();

	/* 

	2. Set Header

	*/

	function setHeader()
	{
		if($j(window).scrollTop() > 91)
		{
			header.addClass('scrolled');
		}
		else
		{
			header.removeClass('scrolled');
		}
	}

	/* 

	3. Init Menu

	*/

	function initMenu()
	{
		if($j('.menu').length)
		{
			var menu = $j('.menu');
			var hamburger = $j('.hamburger');
			var close = $j('.menu_close');

			hamburger.on('click', function()
			{
				menu.toggleClass('active');
			});

			close.on('click', function()
			{
				menu.toggleClass('active');
			});
		}
	}

	/* 

	4. Init Home Slider

	*/

	function initHomeSlider()
	{
		if($j('.home_slider').length)
		{
			var homeSlider = $j('.home_slider');
			homeSlider.owlCarousel(
			{
				items:1,
				autoplay:true,
				loop:true,
				nav:false,
				smartSpeed:1200
			});

			/* Custom dots events */
			if($j('.home_slider_custom_dot').length)
			{
				$j('.home_slider_custom_dot').on('click', function()
				{
					$j('.home_slider_custom_dot').removeClass('active');
					$j(this).addClass('active');
					homeSlider.trigger('to.owl.carousel', [$j(this).index(), 1200]);
				});
			}

			/* Change active class for dots when slide changes by nav or touch */
			homeSlider.on('changed.owl.carousel', function(event)
			{
				$j('.home_slider_custom_dot').removeClass('active');
				$j('.home_slider_custom_dots li').eq(event.page.index).addClass('active');
			});
		}
	}

	/* 

	5. Init Date Picker

	*/

	function initDatePicker()
	{
		if($j('.datepicker').length)
		{
			var datePickers = $j('.datepicker');
			datePickers.each(function()
			{
				var dp = $j(this);
				// Uncomment to use date as a placeholder
				// var date = new Date();
				// var dateM = date.getMonth() + 1;
				// var dateD = date.getDate();
				// var dateY = date.getFullYear();
				// var dateFinal = dateM + '/' + dateD + '/' + dateY;
				var placeholder = dp.data('placeholder');
				dp.val(placeholder);
				dp.datepicker();
			});
		}	
	}

	/* 

	6. Init SVG

	*/

	function initSvg()
	{
		if($j('img.svg').length)
		{
			jQuery('img.svg').each(function()
			{
				var $jimg = jQuery(this);
				var imgID = $jimg.attr('id');
				var imgClass = $jimg.attr('class');
				var imgURL = $jimg.attr('src');

				jQuery.get(imgURL, function(data)
				{
					// Get the SVG tag, ignore the rest
					var $jsvg = jQuery(data).find('svg');

					// Add replaced image's ID to the new SVG
					if(typeof imgID !== 'undefined') {
					$jsvg = $jsvg.attr('id', imgID);
					}
					// Add replaced image's classes to the new SVG
					if(typeof imgClass !== 'undefined') {
					$jsvg = $jsvg.attr('class', imgClass+' replaced-svg');
					}

					// Remove any invalid XML tags as per http://validator.w3.org
					$jsvg = $jsvg.removeAttr('xmlns:a');

					// Replace image with new SVG
					$jimg.replaceWith($jsvg);
				}, 'xml');
			});
		}	
	}

	/* 

	7. Init Gallery

	*/

	function initGallery()
	{
		if($j('.gallery_slider').length)
		{
			var gallerySlider = $j('.gallery_slider');
			gallerySlider.owlCarousel(
			{
				items:4,
				loop:false,
				autoplay:false,
				dots:false,
				nav:false,
				smartSpeed:1200,
				responsive:
				{
					0:{items:1},
					576:{items:2},
					768:{items:3},
					992:{items:4}
				}
			});

			if($j('.colorbox').length)
			{
				$j('.colorbox').colorbox(
				{
					rel:'colorbox',
					photo: true,
					maxWidth:'95%',
					maxHeight:'95%'
				});
			}
		}
	}

	/* 

	8. Init Testimonials Slider

	*/

	function initTestSlider()
	{
		if($j('.test_slider').length)
		{
			var testSlider = $j('.test_slider');
			testSlider.owlCarousel(
			{
				items:3,
				autoplay:true,
				loop:true,
				smartSpeed:1200,
				dots:false,
				nav:false,
				margin:10,
				autoplayHoverPause:true,
				responsive:
				{
					0:{items:1},
					768:{items:2},
					992:{items:3}
				}
			});
		}
	}

	/* 

	9. Init Booking Slider

	*/

	function initBookingSlider()
	{
		if($j('.booking_slider').length)
		{
			var bookingSlider = $j('.booking_slider');
			bookingSlider.owlCarousel(
			{
				items:4,
				autoplay:true,
				autoplayHoverPause:true,
				loop:true,
				smartSpeed:1200,
				dots:false,
				nav:false,
				margin:30,
				responsive:
				{
					0:{items:1},
					768:{items:2},
					992:{items:4}
				}
			});
		}
	}

	/* 

	10. Init Blog Slider

	*/

	function initBlogSlider()
	{
		if($j('.blog_slider').length)
		{
			var blogSlider = $j('.blog_slider');
			blogSlider.owlCarousel(
			{
				items:4,
				autoplay:true,
				loop:true,
				smartSpeed:1200,
				dots:false,
				nav:false,
				margin:2,
				responsive:
				{
					0:{items:1},
					768:{items:2},
					992:{items:4}
				}
			});
		}
	}

});